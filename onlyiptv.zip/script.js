
function watchChannel(channelName) {
  alert("Cargando " + channelName + "...");
}
